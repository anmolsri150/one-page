Open files folder
and run main.exe